

#include <REG52.h>

sbit en1=P3^0;
sbit en2=P3^1;

void delay(unsigned int cnt);
void display(unsigned char d1,unsigned char d2);

// common anode
//unsigned char SSD[16]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90,0x88,0x83,0xC6,0xA1,0x86,0x8E};
//common cathode
unsigned char SSD[16]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71};
unsigned char cnt=0;

void main(){
	P2=0x00;
	P3=0x00;
	
	while(1) display(9,10);
}

void delay(unsigned int time){
	int opt;
	for(opt=0;opt<time;opt++);
}

void display(unsigned char d1,unsigned char d2){
	P2=SSD[d1];
	en1=1;
	delay(3000);
	en1=0;
	
	P2=SSD[d2];
	en2=1;
	delay(3000);
	en2=0;
}

