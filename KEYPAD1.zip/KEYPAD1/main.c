

#include<reg52.h>

#define KEY_PORT    P2
#define	LED					P1

sbit 	row0=P2^4;
sbit 	row1=P2^5;
sbit	row2=P2^6;
sbit	row3=P2^7;

unsigned char getKey();

unsigned char keypad[4][4]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
unsigned char	output[4]={0xFE,0xFD,0xFB,0xF7};
unsigned row,col,key_value;
bit    found=0;

void main(){
		//common cathode
		unsigned char SSD[16]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,
		0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71};
    KEY_PORT=0xF0;
		LED=0x00;
    while(1) {
        LED=SSD[getKey()];	
    }
}

unsigned char getKey(){
		
    static unsigned char i=0;
	
		for (i=0;i<4;i++){
            KEY_PORT=output[i];
            if((KEY_PORT&0xF0)!=0xF0)  
            {   col=i;
                found=1;
                break;
            }
        }

        if(row0==0) row=0;
        else if (row1==0)   row=1;
        else if (row2==0)   row=2;
        else if (row3==0)    row=3;

        if(found==1)
					return key_value=keypad[row][col];   
				found=0;
}

