/*
AT89C52 8051 Interface to Character LCD
and Matrix Keypad Programming in C using Keil
*/

#include <REG52.h>

#define DPORT				P2
#define KEY_PORT    P1

/*Keypad rows setting*/
sbit 	row0=P1^4;
sbit 	row1=P1^5;
sbit	row2=P1^6;
sbit	row3=P1^7;

/*
RS bit 0
RW to  GND
EN bit 1
*/

void	lcdInit();
void	lcdCmd(unsigned char cmd);
void	lcdDat(unsigned char dat);
void	lcdStr(unsigned char *str);
void	lcdXY(unsigned char x, unsigned char y);
void 	_delay_us(unsigned int t);
void 	_delay_ms(unsigned int T);
void	lcdClear();

/**********KeyPad*************/
unsigned char getKey();

unsigned char keypad[4][4]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
unsigned char	output[4]={0xFE,0xFD,0xFB,0xF7};
unsigned row,col,key_value;
bit    found=0;

unsigned char temp;

int main(void)
{	
	  unsigned char keyVal,pressCnt=0;
	  unsigned char keyStr[16];
	  unsigned int i=0;
		unsigned char keyChar[16]={'7','8','9','F','4','5','6','E','1','2','3','D','A','0','B','C'};
	  lcdInit();
		KEY_PORT=0xF0;
	  lcdXY(1,1);
	  P3=0x00;
		lcdStr("Enter Key Value:");
		lcdXY(1,2);
    while(1)
    {
			keyVal=getKey();
			if(found==1){
				lcdDat(keyChar[keyVal]);
				found=0;
				pressCnt++;
				for(i=0;i<32800;i++);
			}
			if(pressCnt>16){
				pressCnt=0;
				for(i=0;i<50000;i++);
				lcdClear();
				lcdXY(1,1);
				lcdStr("Enter Key Value:");
				lcdXY(1,2);
			}
    }
		
}


void lcdCmd(unsigned char cmd){
	temp=0x02;
	DPORT=temp|(cmd&0xF0);
	_delay_us(10);
	temp=0x00;
	DPORT=temp|(cmd&0xF0);
	_delay_us(100);
	
	temp=0x02;
	DPORT=temp|(cmd<<4);
	_delay_us(10);
	temp=0x00;
	DPORT=temp|(cmd<<4);
}

void lcdDat(unsigned char dat){
	temp=0x03;
	DPORT=temp|(dat&0xF0);
	_delay_us(10);
	temp=0x01;
	DPORT=temp|(dat&0xF0);
	_delay_us(100);
	
	temp=0x03;
	DPORT=temp|(dat<<4);
	_delay_us(10);
	temp=0x01;
	DPORT=temp|(dat<<4);
}

void lcdInit(){
	
	DPORT=0x00;
	_delay_ms(2);
	lcdCmd(0x33);
	_delay_us(100);
	lcdCmd(0x32);
	_delay_us(100);
	/*2-Lines Mode 4-Bit*/
	lcdCmd(0x28);
	_delay_us(100);
	/*Display On Cursor Blink*/
	lcdCmd(0x0F);
	_delay_us(100);
	/*Clear Screen*/
	lcdCmd(0x01);
	_delay_ms(2);
	/*Cursor Increment*/
	lcdCmd(0x06);
	_delay_us(100);
}

void lcdStr(unsigned char *str){
	unsigned char i=0;
	while(str[i]!=0){
		lcdDat(str[i]);
		i++;
	}
}

void lcdXY(unsigned char x, unsigned char y){
	/*20x4 LCD Address */
	//unsigned char tbe[]={0x80,0xC0,0x94,0xD4};	
	/*16x2 LCD Address*/
	unsigned char tbe[]={0x80,0xC0};
	lcdCmd(tbe[y-1]+x-1);
	_delay_us(100);
}

void _delay_us(unsigned int a){
	unsigned int i,j;
	for(i=0;i<5;i++)
		for(j=0;j<a;j++);
}

void _delay_ms(unsigned int b){
	unsigned int i;
	for(i=0;i<b;i++)	_delay_us(1000);
}

void lcdClear(){
	lcdCmd(0x01);
	_delay_us(10);
}

/*4x4 Matrix KeyPad Routine*/
unsigned char getKey(){
		
    static unsigned char i=0;
	
		for (i=0;i<4;i++){
            KEY_PORT=output[i];
            if((KEY_PORT&0xF0)!=0xF0)  
            {   col=i;
                found=1;
                break;
            }
        }

        if(row0==0) row=0;
        else if (row1==0)   row=1;
        else if (row2==0)   row=2;
        else if (row3==0)    row=3;

        if(found==1)
					return key_value=keypad[row][col];   
				found=0;
}
