/*
AT89C52 8051 Interface to Character LCD
Progamming in C using Keil
*/

#include <REG52.h>

#define DPORT	P2

/*
RS bit 0
RW to  GND
EN bit 1
*/

void	lcdInit();
void	lcdCmd(unsigned char cmd);
void	lcdDat(unsigned char dat);
void	lcdStr(unsigned char *str);
void	lcdXY(unsigned char x, unsigned char y);
void 	_delay_us(unsigned int t);
void 	_delay_ms(unsigned int T);
void	lcdClear();

unsigned char temp;

int main(void)
{	
	
	  lcdInit();
	
    while(1)
    {
		lcdXY(1,1);
		lcdStr("Hello World!");
		lcdXY(1,2);
		lcdStr("AT89C52 LCD****");
		lcdXY(1,3);
		lcdStr("Interfacing....");
		lcdXY(1,4);
		lcdStr("Using C in Keil");
		lcdCmd(0x0F);
		_delay_ms(100);
		lcdClear();
		_delay_ms(100);
    }
}

void lcdCmd(unsigned char cmd){
	temp=0x02;
	DPORT=temp|(cmd&0xF0);
	_delay_us(10);
	temp=0x00;
	DPORT=temp|(cmd&0xF0);
	_delay_us(100);
	
	temp=0x02;
	DPORT=temp|(cmd<<4);
	_delay_us(10);
	temp=0x00;
	DPORT=temp|(cmd<<4);
}

void lcdDat(unsigned char dat){
	temp=0x03;
	DPORT=temp|(dat&0xF0);
	_delay_us(10);
	temp=0x01;
	DPORT=temp|(dat&0xF0);
	_delay_us(100);
	
	temp=0x03;
	DPORT=temp|(dat<<4);
	_delay_us(10);
	temp=0x01;
	DPORT=temp|(dat<<4);
}

void lcdInit(){
	
	DPORT=0x00;
	_delay_ms(2);
	lcdCmd(0x33);
	_delay_us(100);
	lcdCmd(0x32);
	_delay_us(100);
	lcdCmd(0x28);
	_delay_us(100);
	lcdCmd(0x0E);
	_delay_us(100);
	lcdCmd(0x01);
	_delay_ms(2);
	lcdCmd(0x06);
	_delay_us(100);
}

void lcdStr(unsigned char *str){
	unsigned char i=0;
	while(str[i]!=0){
		lcdDat(str[i]);
		i++;
	}
}

void lcdXY(unsigned char x, unsigned char y){
	unsigned char tbe[]={0x80,0xC0,0x94,0xD4};	// 20x4
	lcdCmd(tbe[y-1]+x-1);
	_delay_us(100);
}

void _delay_us(unsigned int a){
	unsigned int i,j;
	for(i=0;i<5;i++)
		for(j=0;j<a;j++);
}

void _delay_ms(unsigned int b){
	unsigned int i;
	for(i=0;i<b;i++)	_delay_us(1000);
}

void lcdClear(){
	lcdCmd(0x01);
	_delay_us(10);
}
